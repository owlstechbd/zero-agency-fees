$(document).ready(function () {
  $('.card-header').click(function () {
      $(this).find('i').toggleClass('fa-plus fa-minus');
      $(this).closest('.card').siblings().find('.card-header i').removeClass('fa-minus').addClass('fa-plus');
      $(this).closest('.card').siblings().find('.card-header').removeClass('active-faq');
      $(this).toggleClass('active-faq');
  });
});




function displayTime() {
  var currentTime = new Date();
  var hours = currentTime.getHours();
  var minutes = currentTime.getMinutes();
  var seconds = currentTime.getSeconds();

  // Add leading zeros if necessary
  hours = (hours < 10 ? "0" : "") + hours;
  minutes = (minutes < 10 ? "0" : "") + minutes;

  // Format the time
  var formattedTime = hours + ":" + minutes ;

  // Display the time on the webpage
  document.getElementById("current-time").innerHTML =   formattedTime;
}

// Update the time every second
setInterval(displayTime, 1000);

// Display the time when the page loads
displayTime();