$(document).ready(function () {
  $('.card-header').click(function () {
      $(this).find('i').toggleClass('fa-plus fa-minus');
      $(this).closest('.card').siblings().find('.card-header i').removeClass('fa-minus').addClass('fa-plus');
      $(this).closest('.card').siblings().find('.card-header').removeClass('active-faq');
      $(this).toggleClass('active-faq');
  });
});
